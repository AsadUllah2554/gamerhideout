import React, {useState} from 'react'
import Cover from '../../img/mainn.jpg'
import ReactModal from 'react-modal';
import axios from 'axios'
// import Profile from '../../img/usama.jpeg'
import './ProfileCard.css'
import { useUserContext } from '../../hooks/useUserContext'

const ProfileCard = () => {
    const {user} = useUserContext();
    console.log("latest user "+ JSON.stringify(user))
    console.log(user.profilePicture)
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleModalOpen = () => {
      setIsModalOpen(true);
    };
  
    const handleModalClose = () => {
      setIsModalOpen(false);
    };

    const handleEditProfile = () => {

    }
    const editProfile = async () => {

      try {
        const response = await axios.post(`http://localhost:5000/auth/profile/edit`, {
        postId: data._id,  
        comment: comment, 
        user
        });
       console.log(response.data); // Assuming the response contains the newly added comment
        setComment(''); // Clear the comment input field after submission
      } catch (error) {
        console.error('Error adding comment:', error);
        // Handle error, show a message, etc.
      }
      
    }

  return (
   
   <div className="ProfileCard">

<div className="ProfileImages">
<img src={Cover} alt="cover" />
<img src={user.profilePicture} alt="profile" />
</div>

<div className="ProfileName">
    <span> {user.name}</span>
    <span >{user.tagline.charAt(0).toUpperCase() + user.tagline.slice(1)}</span>

</div>

<div className="followStatus">
<hr />
<div>
    <div className="follow">
        <span>69</span>
        <span>Followings</span>
    </div>
    <div className='vl'></div>
    <div className="follow">
        <span>2,400</span>
        <span>Followers</span>
    </div>
</div>
<hr />
</div>

<span onClick={handleModalOpen}>
    My Profile
</span>
<ReactModal isOpen={isModalOpen} onRequestClose={handleModalClose}>
        {/* Profile data content here */}
        <h2>{user.name}</h2>
        <p>{user.role.charAt(0).toUpperCase() + user.role.slice(1)}</p>
        <p>{user.tagline.charAt(0).toUpperCase() + user.tagline.slice(1)}</p>
        {/* { cover photo.. semester.. department ( you can select department once ) } */}
        <img src={user.profilePicture} alt="profile" />
        {/* Add detailed profile information here */}
        <p>{user.email}</p>
        {/* ... other profile details */}
        <button onClick={handleEditProfile}>Edit Profile</button>
        <button onClick={handleModalClose}>&times;</button>
      </ReactModal>
    </div>
  )
}

export default ProfileCard
