import React, { useState } from 'react';
import './SignInPage.css';
import axios from 'axios';
import { useUserContext } from '../../hooks/useUserContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const SignInPage = ({ prompt, setPrompt, user }) => {
  const [selectedRole, setSelectedRole] = useState('');
  const { setUser } = useUserContext();
  const navigate = useNavigate();
  console.log('user ' + JSON.stringify(user));
  const google = () => {
    window.open('http://localhost:5000/auth/google', '_self');
  };

  const handleRoleSelection = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5000/auth/role-selection',
        { userData: user, role: selectedRole },
        { withCredentials: true, headers: { 'Content-Type': 'application/json' } }
      );

      console.log(response.data);
      if (response.data.success) {
        setUser(response.data.user);
        navigate('/');
      } else {
        console.error('Role selection failed:', response.data.message);
        toast.error('Role selection failed:', response.data.message);
      }
    } catch (error) {
      console.error('Error in role selection:', error);
      toast.error('Error in role selection:', error);
    }
  };

  return (
    <div className="body">
      <div className="header">
        <div className="title">UOL SOCIAL MEDIA</div>
      </div>
      {!prompt ? (
        <div className="content">
          <p>  Welcome to the UOL Social Media App! Connect, 
            collaborate, and engage with your university 
            community in one seamless platform.</p>
          <button className="google-button" onClick={google}>
            <img src="https://img.icons8.com/color/16/000000/google-logo.png" alt="Google icon" />
            Sign in with Google
          </button>
        </div>
      ) : (
        <div className="role-selection">
          <h1>Please confirm your role</h1>
          <div className="role-options">
            <label>
              <input
                type="radio"
                name="role"
                value="teacher"
                checked={selectedRole === 'teacher'}
                onChange={() => setSelectedRole('teacher')}
              />
              Teacher
            </label>
            <label>
              <input
                type="radio"
                name="role"
                value="admin"
                checked={selectedRole === 'admin'}
                onChange={() => setSelectedRole('admin')}
              />
              Admin
            </label>
          </div>
          <button className="submit-button" onClick={handleRoleSelection}>
            Submit
          </button>
        </div>
      )}
    </div>
  );
};

export default SignInPage;
